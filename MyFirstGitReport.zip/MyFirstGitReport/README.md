# Mein erstes Git-Projekt

Dies ist mein erstes Projekt mit Git. Hier teste ich die grundlegenden Befehle und das Arbeiten.

- Ich habe ein Repository erstellt
-Ich habe eine README.md hinzugefügt
-Ich lerne die ersten Git-Befehle

## Fragen & Antworten

## Fragen & Antworten

**Was bedeutet „Staging“ in Git?**
Staging bedeutet, dass Dateien für den nächsten Commit vorgemerkt werden. Sie liegen damit in der *Staging Area*.

**Wie heißt der aktive Branch direkt nach dem Initialisieren des Repositories?**
Standardmäßig heißt er `main` (früher oft `master`).

**Womit kann man sich alle bisherigen Commits anzeigen lassen?**
Mit `git log`.

**Welcher Befehl zeigt den aktuellen Status des Repositories an?**
Mit `git status`.

**Wozu dient die Datei .gitignore?**
In der Datei `.gitignore` werden Muster für Dateien/Ordner definiert, die Git ignorieren soll – etwa temporäre Dateien oder Build-Outputs.
